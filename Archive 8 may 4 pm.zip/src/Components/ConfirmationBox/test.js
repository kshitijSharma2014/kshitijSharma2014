var updateFileData;

$('#exportTable').on('click', 'tbody .rowEditbtn', function () {
    updateFileData = expTable.row($(this).closest('tr')).data();
    $('#updateFileModal').show();
})

function hideUpdateFileModal() {
    $('#updateFileModal').hide();
}

$('#importNewFilebtn').on('click', function() {
    $('#importFileModal').show();
})


function hideImportFileModal() {
    $('#importFileModal').hide();
}
