var CryptoJS = require("crypto-js");

var key = CryptoJS.enc.Utf8.parse('8080808080808080');  
var iv = CryptoJS.enc.Utf8.parse('8080808080808080');  

export const encryptData = (data) => {
    var encryptedData = CryptoJS.AES.encrypt(data, key,  
        {
           iv: iv,  
          
        }); 
        return encryptedData.toString();
}

export const decryptData = (data) => {
    var decrypted = CryptoJS.AES.decrypt(data, key, { 
            iv : iv
        });
    return decrypted.toString(CryptoJS.enc.Utf8);
}