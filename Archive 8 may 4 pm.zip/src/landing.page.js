import React from "react";
import auth from "./auth";
import './index.css';
import $ from 'jquery';
import { encryptData, decryptData } from './Utils';

const COUNTDOWNTIMER = 60;
const baseApi = "http://localhost:53400/api/plm";

class LandingPage extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            otp: '',
            warningText: '',
            OtpSent: false,
            seconds: COUNTDOWNTIMER,
        }
        this.secondsRemaining = null;
        this.intervalHandle = null;
        this.startCountDown = this.startCountDown.bind(this);
        this.tick = this.tick.bind(this);
    }

    componentDidMount() {
        this.GenerateOTP();
        this.startCountDown();
    }

    tick() {
        var sec = this.secondsRemaining - 1;
        this.setState({
            seconds: sec,
        })

        if (sec < 10) {
            this.setState({
                seconds: "0" + this.state.seconds,
            })
        }

        if (sec === 0) {
            clearInterval(this.intervalHandle);
        }
        this.secondsRemaining--
    }

    startCountDown() {
        this.intervalHandle = setInterval(this.tick, 1000);
        this.secondsRemaining = COUNTDOWNTIMER;
        this.setState({
            isClicked: true
        })
    }

    GenerateOTP = () => {
        const that = this;
        const phoneno = decryptData(encodeURI(this.props.location.pathname).slice(1));
        const payload = encryptData(JSON.stringify({
            phoneno: phoneno,
        }));

        $.post(`${baseApi}/GenerateOTP`, { data: payload }, function (res) {
            const response = decryptData(res.data);
            if (JSON.parse(response).Status === '5001') {
                that.setState({ OtpSent: true })
            }
        }).fail(() => {

        })
    }


    onOtpChange = (event) => {
        this.setState({ otp: event.target.value })
    }

    onOtpSubmit = () => {
        const that = this;
        // auth.login(() => {
        //     this.props.history.push(`${that.props.history.location.pathname}/siteVerify`)

        // });
        const otp = this.state.otp;
        if (otp === '') {
            this.setState({ warningText: 'Please enter the OTP' })
            return;
        }
        const phoneNum = decryptData(encodeURI(this.props.location.pathname).slice(1));
        const payload = encryptData(JSON.stringify({
            phone: phoneNum,
            otp: otp
        }));
        $.post(`${baseApi}/VerifyOTP`, { data: payload }, function (res) {
            const response = decryptData(res.data);
            if (JSON.parse(response).Status === '5001') {
                auth.login(() => {
                    that.props.history.push("/siteVerify");
                });
            } else {
                that.setState({ warningText: 'The OTP you entered could not be authenticated. Please try again' })
            }
        })
            .fail(() => {
                that.setState({ warningText: 'The OTP you entered could not be authenticated. Please try again' })

            })
    }

    resendOtp = () => {
        if (this.state.seconds === '00') {
            this.GenerateOTP();
            this.startCountDown();
        }
    }

    render() {
        return (
            <div className="full_width full_height loginPageContainer">
                <img alt="jioLogo" src={require('./Components/NavigationBar/jioLogo.png')} className="jioLogoOTPpage" />
                <div className="bold otpTitle">Verify Mobile Number</div>
                {/*this.state.OtpSent && <div className="otpBody">OTP has been sent to your registered mobile number. Please enter it below</div>*/}
                <div className="otpBody">OTP has been sent to your registered mobile number. Please enter it below</div>
                <input placeholder="Enter OTP" className="otpInputBox" type="number" maxlength="6" onChange={this.onOtpChange} />
                <button className="otpSubmit" onClick={this.onOtpSubmit}>Submit</button>
                {this.state.warningText !== '' && <div className="warningMessage">{this.state.warningText}</div>}
                <div className="otpResend" onClick={this.resendOtp}><span>Click here to resend otp: </span><span>{this.state.seconds}
                </span></div>
            </div>
        );
    }
}

export default LandingPage;